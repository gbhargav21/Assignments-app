import sqlite3
conn = sqlite3.connect('main.db', check_same_thread=False)
cursor = conn.cursor()
#cursor.execute('''PRAGMA table_info(assignments)
#''')
#'''cursor.execute('''SELECT b.*, a.assignment_name, a.description, a.file, a.price,a.last_date FROM bids b
#                  JOIN assignments a ON b.assignment_id = a.assignment_id
 #                 WHERE b.freelancer_email = ? and b.status="Accepted"''', ('test6@gmail.com',))'''

cursor.execute('SELECT * FROM bids')
column_names = [col[0] for col in cursor.description]
bids = cursor.fetchall()
import pandas as pd
df = pd.DataFrame(bids, columns = column_names)
print(df)
