from flask import Flask, request, session, redirect, url_for, render_template,flash,send_from_directory
import sqlite3
import os
import uuid
from flask import jsonify
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static\data-files'
upload_folder = app.config['UPLOAD_FOLDER']


# Secret key for session management
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

conn = sqlite3.connect('main.db', check_same_thread=False)
cursor = conn.cursor()

def create_database_tables():
    conn = sqlite3.connect('main.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (email TEXT PRIMARY KEY, password TEXT, name TEXT, phone TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS assignments (id TEXT PRIMARY KEY, name TEXT, description TEXT, file TEXT, last_date TEXT, price REAL, email TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS freelancers (email TEXT PRIMARY KEY,name TEXT,phone TEXT,password TEXT,skills TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS bids (id TEXT PRIMARY KEY, freelancer_email TEXT,user_email TEXT,assignment_id TEXT,price REAL,status TEXT,
    FOREIGN KEY (freelancer_email) REFERENCES freelancers(email),
    FOREIGN KEY (user_email) REFERENCES users(email),
    FOREIGN KEY (assignment_id) REFERENCES assignments(id))''')
    conn.commit()

create_database_tables()
# Connect to the database



# Home page
@app.route('/')
def home():
    return render_template("home.html")
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Check if the user is trying to create a new account
        if request.form.get('create_account'):
            return redirect(url_for('create_user'))

        # Get the user input
        email = request.form['email']
        password = request.form['password']

        # Query the database to see if the user exists
        cursor.execute('''SELECT * FROM users WHERE email = ? AND password = ?''', (email, password))
        user = cursor.fetchone()

        # If the user exists, add the user to the session
        if user:
            session['username'] = email

            # Query the database to fetch the user's name
            cursor.execute('''SELECT name FROM users WHERE email = ?''', (email,))
            name = cursor.fetchone()[0]

            # Redirect the user to the user dashboard
            return redirect(url_for('user_dashboard'))

        # If the user doesn't exist, return an error message
        return 'Invalid email or password'

    # If the request is a GET request, render the login template
    return render_template('login.html')


# Logout page
@app.route('/logout')
def logout():
    # Remove the user from the session
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/create_account', methods=['GET', 'POST'])
def create_user():
    if request.method == 'POST':
        # Get the user input
        email = request.form['email']
        password = request.form['password']
        name = request.form['name']
        phone = request.form['phone']

        # Insert the new user into the database
        cursor.execute('''INSERT INTO users (email, password, name, phone) VALUES (?, ?, ?, ?)''', (email, password, name, phone))
        conn.commit()

        # Redirect to the success page
        return redirect(url_for('success'))

    # If the request is a GET request, render the create user template
    return render_template('create_user.html')

@app.route('/success')
def success():
    # Render the success template with a message and a link to the login page
    return render_template('success.html', message='User created successfully')

@app.route('/create_free_lancer', methods=['GET', 'POST'])
def create_freelancer():
    if request.method == 'POST':
        # Get the user input
        email = request.form['email']
        password = request.form['password']
        name = request.form['name']
        phone = request.form['phone']
        skills = request.form['skills']


        # Insert the new freelancer into the database
        cursor.execute('''INSERT INTO freelancers (email, password, name, phone, skills) VALUES (?, ?, ?, ?, ?)''', (email, password, name, phone, skills))
        conn.commit()

        return render_template("success2.html")

    # If the request is a GET request, render the create freelancer template
    return render_template('freelancer-user-account.html')

@app.route('/freelancer_login', methods=['GET', 'POST'])
def freelancer_login():
    if request.method == 'POST':
        # Get the user input
        email = request.form['email']
        password = request.form['password']

        # Check if the email and password match a freelancer in the database
        cursor.execute('''SELECT * FROM freelancers WHERE email=? AND password=?''', (email, password))
        freelancer = cursor.fetchone()
        if freelancer:
            # Save the user's email in the session
            session['username'] = email
            return redirect(url_for('freelancer_dashboard'))
        else:
            flash('Invalid email or password')
            return redirect(url_for('freelancer_login'))

    # If the request is a GET request, render the freelancer login template
    return render_template('freelancer-login.html')



@app.route('/freelancer_dashboard')
def freelancer_dashboard():
    # Get the freelancer's name
    email = session['username']
    cursor.execute('''SELECT name FROM freelancers WHERE email=?''', (email,))
    freelancer_name = cursor.fetchone()[0]

    # Get the available assignments
    cursor.execute('''SELECT * FROM assignments''')
    assignments = cursor.fetchall()

    return render_template('freelancer-dashboard.html', freelancer_name=freelancer_name, assignments=assignments)

@app.route('/bid_assignment/<assignment_id>', methods=['POST'])
def bid_assignment(assignment_id):
    if 'username' in session:
        freelancer_email = session['username']
        price = request.form['price']
        status = 'pending'
        cursor.execute('''SELECT * FROM bids WHERE freelancer_email = ? AND assignment_id = ?''', (freelancer_email, assignment_id))
        if cursor.fetchone() is None:
            cursor.execute('''INSERT INTO bids(id, freelancer_email, assignment_id, price, status) VALUES(?,?,?,?,?)''', (str(uuid.uuid4()), freelancer_email, assignment_id, price, status))
            conn.commit()
            return redirect(url_for('freelancer_dashboard'))
        else:
            flash("You already placed a bid on this assignment")
            return redirect(url_for('freelancer_dashboard'))


@app.route('/accept_assignment/<assignment_id>', methods=['POST'])
def accept_assignment(assignment_id):
    if 'username' in session:
        freelancer_email = session['username']
        # Fetch the user's email id from the database
        cursor.execute('''SELECT email FROM assignments WHERE assignment_id=?''', (assignment_id,))
        user_email = cursor.fetchone()[0]

        cursor.execute('''INSERT INTO bids(freelancer_email, user_email, assignment_id, status) VALUES(?,?,?,?)''', (freelancer_email, user_email, assignment_id, 'accepted'))
        conn.commit()
        return redirect(url_for('freelancer_dashboard'))
    return redirect(url_for('freelancer_login'))



@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(upload_folder, filename, as_attachment=True)


@app.route('/freelancer_history')
def freelancer_history():
    if 'username' not in session:
        return redirect(url_for('freelancer_login'))

    email = session['username']
    cursor.execute('''SELECT b.*, a.assignment_name, a.description, a.last_date, a.price FROM bids b 
                  JOIN assignments a ON b.assignment_id = a.assignment_id 
                  WHERE b.freelancer_email = ? and b.status="accepted"''', (email,))

    history = cursor.fetchall()
    cursor.execute('''SELECT b.*, a.assignment_name, a.description, a.last_date, a.price FROM bids b 
                  JOIN assignments a ON b.assignment_id = a.assignment_id 
                  WHERE b.freelancer_email = ? and b.status="accepted"''', (email,))

    history_bidded = cursor.fetchall()
    return render_template("freelancer_history.html", history=history, history_bidded=history_bidded)



@app.route('/get_assignments', methods=['GET'])
def get_assignments():
    email = session['username']
    # Query the database to fetch the assignments posted by the user along with the bid status
    cursor.execute('''SELECT a.*, b.status FROM assignments a LEFT JOIN bids b ON a.assignment_id = b.assignment_id WHERE a.email = ?''', (email,))
    assignments = cursor.fetchall()
    return jsonify({'assignments': assignments})





@app.route('/post_assignment', methods=['POST'])
def post_assignment():
    if request.method == 'POST':
        # get the data from the form
        print(request.form)

        assignment_name = request.form['assignment_name']
        description = request.form['description']
        file = request.files['file']
        last_date = request.form['last_date']
        price = request.form['price']
        email = session['username']
        id = str(uuid.uuid1())

        # save the file
        file.save(os.path.join(upload_folder, id))

        # insert the data into the database
        cursor.execute('''INSERT INTO assignments (assignment_id, assignment_name, description, file, last_date, price, email) VALUES (?,?,?,?,?,?,?)''', (id, assignment_name, description, id, last_date, price, email))
        conn.commit()

        # return success message
        return jsonify(status=200)

# Flask server code

@app.route('/user-dashboard')
def user_dashboard():
    email = session['username']
    return render_template('collectdata.html')

@app.route('/user-dashboard-data')
def user_dashboard_data():
    email = session['username']
    cursor.execute('''SELECT name FROM users WHERE email = ?''', (email,))
    name = cursor.fetchone()[0]
    cursor.execute('''SELECT a.*, b.status FROM assignments a LEFT JOIN bids b on a.assignment_id = b.assignment_id where a.email = ?''', (email, ))
    assignments1 = cursor.fetchall()
    # Convert the data to a list of dictionaries
    assignments = [
        {
            'assignment_id': row[0],
            'name': row[1],
            'description': row[2],
            'price': row[5],
            'status': row[7] if row[7] else 'Awaiting Status'
        }
        for row in assignments1
    ]
    return jsonify(assignments=assignments, name=name)

# HTML/Javascript code




if __name__ == '__main__':
    app.run()
