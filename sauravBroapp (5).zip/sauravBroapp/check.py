def greater_than_half(arr):
    if arr == None or len(arr) == 0:
        return None
    n = len(arr)
    threshold = n // 2
    result = []
    for i in arr:
        if i > threshold:
            result.append(i)
    if len(result) == 0:
        return " "
    return " ".join(map(str,sorted(result, reverse=True)))

n=int(input())
arr=[]
for i in range(n):
    a=int(input())
    arr.append(a)
print(greater_than_half(arr))